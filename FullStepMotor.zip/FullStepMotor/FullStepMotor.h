#include <Arduino.h>;

// Абстракция полношагового двигателя для драйвера ULN2003
class FullStepMotorClass{
public:
  // Конструктор
  // in1 - выход IN1
  // in2 - выход IN2
  // in3 - выход IN3
  // in4 - выход IN4
  // rpm - скорость вращения вала, об/мин
  FullStepMotorClass(int in1, int in2, int in3, int in4, double rpm = 15);

  // Устанавливает скорость вращения
  // rpm - скорость вращения вала, об/мин
  void SetSpeed(double rpm);

  // Делает 4 шага против часовой стрелки
  void Do4StepsCounterClockwise();

  // Делает 4 шага по часовой стрелке
  void Do4StepsClockwise();
private:
  // Задержка между шагами в микросекундах
  int _dl_mcs;

  // выходы
  int _in1, _in2, _in3, _in4;
};
