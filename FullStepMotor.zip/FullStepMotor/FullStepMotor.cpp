#include <FullStepMotor.h>

FullStepMotorClass::FullStepMotorClass(int in1, int in2, int in3, int in4, double rpm = 15)
{
  _in1 = in1;
  _in2 = in2;
  _in3 = in3;
  _in4 = in4;

  pinMode(_in1, OUTPUT);
  pinMode(_in2, OUTPUT);
  pinMode(_in3, OUTPUT);
  pinMode(_in4, OUTPUT);

  _dl_mcs = 10e6 * 60 / (509 * 4 * rpm);
}

void FullStepMotorClass::SetSpeed(double rpm)
{
  _dl_mcs = 10e6 * 60 / (509 * 4 * rpm);
}

void FullStepMotorClass::Do4StepsCounterClockwise()
{
  digitalWrite(_in1, HIGH);
  digitalWrite(_in2, HIGH);
  digitalWrite(_in3, LOW);
  digitalWrite(_in4, LOW);
  delayMicroseconds(_dl_mcs);

  digitalWrite(_in1, LOW);
  digitalWrite(_in2, HIGH);
  digitalWrite(_in3, HIGH);
  digitalWrite(_in4, LOW);
  delayMicroseconds(_dl_mcs);

  digitalWrite(_in1, LOW);
  digitalWrite(_in2, LOW);
  digitalWrite(_in3, HIGH);
  digitalWrite(_in4, HIGH);
  delayMicroseconds(_dl_mcs);

  digitalWrite(_in1, HIGH);
  digitalWrite(_in2, LOW);
  digitalWrite(_in3, LOW);
  digitalWrite(_in4, HIGH);
  delayMicroseconds(_dl_mcs);
}

void FullStepMotorClass::Do4StepsClockwise()
{
  digitalWrite(_in1, HIGH);
  digitalWrite(_in2, HIGH);
  digitalWrite(_in3, LOW);
  digitalWrite(_in4, LOW);
  delayMicroseconds(_dl_mcs);

  digitalWrite(_in1, HIGH);
  digitalWrite(_in2, LOW);
  digitalWrite(_in3, LOW);
  digitalWrite(_in4, HIGH);
  delayMicroseconds(_dl_mcs);

  digitalWrite(_in1, LOW);
  digitalWrite(_in2, LOW);
  digitalWrite(_in3, HIGH);
  digitalWrite(_in4, HIGH);
  delayMicroseconds(_dl_mcs);

  digitalWrite(_in1, LOW);
  digitalWrite(_in2, HIGH);
  digitalWrite(_in3, HIGH);
  digitalWrite(_in4, LOW);
  delayMicroseconds(_dl_mcs);
}
