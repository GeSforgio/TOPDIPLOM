#include <Machine.h>

MachineClass::MachineClass()
{
  MachineClass::leftMotor = new FullStepMotorClass(L_MOTOR_IN1, L_MOTOR_IN2, L_MOTOR_IN3, L_MOTOR_IN4, 16.1);

  MachineClass::rightMotor = new FullStepMotorClass(R_MOTOR_IN1, R_MOTOR_IN2, R_MOTOR_IN3, R_MOTOR_IN4, 16.1);

  MachineClass::servo.attach(SERVO);
  MachineClass::TurnEchoToBeginState();

  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);
  Serial.begin(9600);
}

void MachineClass::SetSpeed(double rpm)
{
  MachineClass::rightMotor->SetSpeed(rpm);
  MachineClass::leftMotor->SetSpeed(rpm);
}

void MachineClass::LeftMotorMoveForward()
{
  MachineClass::leftMotor->Do4StepsCounterClockwise();
}

void MachineClass::LeftMotorMoveBackward()
{
  MachineClass::leftMotor->Do4StepsClockwise();
}

void MachineClass::RightMotorMoveForward()
{
  MachineClass::rightMotor->Do4StepsClockwise();
}

void MachineClass::RightMotorMoveBackward()
{
  MachineClass::rightMotor->Do4StepsCounterClockwise();
}

void MachineClass::TurnEchoRight()
{
  MachineClass::servo.write(0);
}

void MachineClass::TurnEchoLeft()
{
  MachineClass::servo.write(180);
}

void MachineClass::TurnEchoToBeginState()
{
  MachineClass::servo.write(90);
}

double MachineClass::LengthToNearestHindrance()
{
  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);

  // Получить длительность получения эхо
  double duration = pulseIn(ECHO, HIGH);

  // расстояние = (длительность в мкс) * (скорость звука = 0.00034 м/мкс) / (так как звук идёт туда и обратно, надо поделить на 2)
  double s = duration * 0.00034 / 2;

  return s;
}

void MachineClass::MoveForward()
{
  MachineClass::LeftMotorMoveForward();
  MachineClass::RightMotorMoveForward();
}

void MachineClass::MoveForward(double length, UnitOfMeasurement unit)
{
  switch(unit)
  {
    case MM:
      length *= 1;
      break;
    case SM:
      length *= 10;
      break;
    case M:
      length *= 1000;
      break;
  }

  int howTimesToMove = MachineClass::HowTimesToMove(length);

  for (int i = 0; i < howTimesToMove; i++)
  {
    MachineClass::MoveForward();
  }
}

void MachineClass::MoveBackward()
{
  MachineClass::LeftMotorMoveBackward();
  MachineClass::RightMotorMoveBackward();
}

void MachineClass::MoveBackward(double length, UnitOfMeasurement unit)
{
  switch(unit)
  {
    case MM:
      length *= 1;
      break;
    case SM:
      length *= 10;
      break;
    case M:
      length *= 1000;
      break;
  }

  int howTimesToMove = MachineClass::HowTimesToMove(length);

  for (int i = 0; i < howTimesToMove; i++)
  {
    MachineClass::MoveBackward();
  }
}

void MachineClass::TurnLeft(AxisOfTurnEnum center)
{
  if (center == BetweenWheels)
  {
    double diametr = MachineClass::MACHINE_WIDTH_MM - MachineClass::WHEEL_DIAMETER_MM;
    double howLengthToMove = diametr * PI / 4;

    int howTimesToMove = MachineClass::HowTimesToMove(howLengthToMove) + 70;

    for (int i = 0; i < howTimesToMove; i++)
    {
      LeftMotorMoveBackward();
      RightMotorMoveForward();
    }
  }
  else
  {
    double radius = MachineClass::MACHINE_WIDTH_MM - MachineClass::WHEEL_DIAMETER_MM;
    double howLengthToMove = 2 * radius * PI / 4;

    int howTimesToMove = MachineClass::HowTimesToMove(howLengthToMove) + 140;

    if (center == RightWheel)
    {
      for (int i = 0; i < howTimesToMove; i++)
      {
        LeftMotorMoveBackward();
      }
    }
    else if (center == LeftWheel)
    {
      for (int i = 0; i < howTimesToMove; i++)
      {
        RightMotorMoveForward();
      }
    }
  }
}

void MachineClass::TurnRight(AxisOfTurnEnum center)
{
  if (center == BetweenWheels)
  {
    double radius = (MachineClass::MACHINE_WIDTH_MM - MachineClass::WHEEL_DIAMETER_MM) / 2;
    double howLengthToMove = 2 * radius * PI / 4;

    int howTimesToMove = MachineClass::HowTimesToMove(howLengthToMove) + 70;

    for (int i = 0; i < howTimesToMove; i++)
    {
      MachineClass::LeftMotorMoveForward();
      MachineClass::RightMotorMoveBackward();
    }
  }
  else
  {
    double radius = MachineClass::MACHINE_WIDTH_MM - MachineClass::WHEEL_DIAMETER_MM;
    double howLengthToMove = 2 * radius * PI / 4;

    int howTimesToMove = MachineClass::HowTimesToMove(howLengthToMove) + 140;

    if (center == RightWheel)
    {
      for (int i = 0; i < howTimesToMove; i++)
      {
        MachineClass::LeftMotorMoveForward();
      }
    }
    else if (center == LeftWheel)
    {
      for (int i = 0; i < howTimesToMove; i++)
      {
        MachineClass::RightMotorMoveBackward();
      }
    }
  }
}

int MachineClass::HowTimesToMove(double length)
{
  return length / (WHEEL_DIAMETER_MM * PI / 490);
}
