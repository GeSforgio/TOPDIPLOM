#pragma once
#include <Arduino.h>
#include <Servo.h>
#include <FullStepMotor.h>

// Ось поворота машины
enum AxisOfTurnEnum{
  // Поворот относительно оси между колёс
  BetweenWheels,

  // Поворот относительно правого колеса
  RightWheel,

  // Поворот относительно левого колеса
  LeftWheel
};

// Единицы измерения
enum UnitOfMeasurement{
  // Милиметры
  MM,

  // Сантиметры
  SM,

  // Метры
  M
};

// Абстракция машинки
class MachineClass{
public:
  // Конструктор
  MachineClass();

  // Поворачивает эхолот вправо
  void TurnEchoRight();

  // Поворачивает эхолот влево
  void TurnEchoLeft();

  // Поворачивает эхолот в исходное состояние
  void TurnEchoToBeginState();

  // Измеряет дальность до ближайшего препятствия
  double LengthToNearestHindrance();

  // Делает 4 шага двигателями вперёд (1.6 мм)
  void MoveForward();

  // Двигается на определённое расстояние вперёд
  // length - расстояние
  // unitOfMeasurement - единицы измерения
  void MoveForward(double length, UnitOfMeasurement unit);

  // Делает 4 шага двигателями назад (1.6 мм)
  void MoveBackward();

  // Двигается на определённое расстояние назад
  // length - расстояние
  // unitOfMeasurement - единицы измерения
  void MoveBackward(double length, UnitOfMeasurement unit);

  // Поворачивает налево относительно одной из осей
  // center - ось поворота
  void TurnLeft(AxisOfTurnEnum center);

  // Поворачивает направо относительно одной из осей
  // center - ось поворота
  void TurnRight(AxisOfTurnEnum center);

  // Вычисляет количество вызовов MoveForward() или MoveBackward() для определённой длины
  // length - расстояние в милиметрах
  int HowTimesToMove(double length);

  // Устанавливает скорость вращения двигателей
  // rpm - скорость вращения вала двигателя, об/мин
  void SetSpeed(double rpm);
private:
  const double WHEEL_WIDTH_MM = 26;
  const double MACHINE_WIDTH_MM = 268;
  const double WHEEL_DIAMETER_MM = 65;

  // L_MOTOR
  const int L_MOTOR_IN1 = 5;
  const int L_MOTOR_IN2 = 4;
  const int L_MOTOR_IN3 = 3;
  const int L_MOTOR_IN4 = 2;
  FullStepMotorClass* leftMotor;
  void LeftMotorMoveForward();
  void LeftMotorMoveBackward();

  // R_MOTOR
  const int R_MOTOR_IN1 = 9;
  const int R_MOTOR_IN2 = 8;
  const int R_MOTOR_IN3 = 7;
  const int R_MOTOR_IN4 = 6;
  FullStepMotorClass* rightMotor;
  void RightMotorMoveForward();
  void RightMotorMoveBackward();

  // SERVO
  Servo servo;
  const int SERVO = 11;

  // ECHOLOC
  const int TRIG = 12;
  const int ECHO = 13;
};
